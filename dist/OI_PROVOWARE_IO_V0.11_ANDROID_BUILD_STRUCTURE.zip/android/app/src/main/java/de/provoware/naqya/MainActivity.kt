package de.provoware.naqya

import android.app.Activity
import android.os.Bundle

/** V0.11 packaging boundary only. Product UI/runtime integration follows native build acceptance. */
class MainActivity: Activity() { override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState) } }
