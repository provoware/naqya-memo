plugins { id("com.android.application"); kotlin("android") }
android { namespace="de.provoware.naqya"; compileSdk=35
 defaultConfig { applicationId="de.provoware.naqya"; minSdk=26; targetSdk=35; versionCode=11; versionName="0.11.0" } }
