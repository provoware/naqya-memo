# Android Buildstruktur V0.11

**Status: BUILD_STRUCTURE_ONLY.** Kein APK wurde in dieser Umgebung gebaut oder auf einem Android-Gerät getestet. Vor Freigabe zwingend: Gradle/SDK Build, Runtime Permissions für Mikrofon/Benachrichtigung, Scoped Storage, Lifecycle-/Background-Tests und Device-Evidence.
