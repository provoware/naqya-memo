# OI - PROVOWARE - IO V0.12.2 – ANDROID Runtime Source

Source/Contract: PASS. Native Build/Device: BLOCKED im aktuellen Runner. V1.0: NO-GO bis 7/7 reale Gates PASS.

Source Acceptance: `./RUN_MOBILE_RUNTIME_ACCEPTANCE.sh`
Native Build: `./RUN_ANDROID_BUILD_GATE.sh`
