OI - PROVOWARE - IO V0.11
1. START_OI_PROVOWARE_IO.sh ausführen.
2. Browser öffnet lokalen Dienst.
3. Projektordner bleibt lokal.
