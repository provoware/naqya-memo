# iOS Packaging-Konzept V0.11

**Status: BUILD_CONCEPT_ONLY.** iPhone/iOS benötigt eine native Xcode-Shell und kann in dieser Linux-Laufzeit nicht gebaut oder signiert werden. V0.11 definiert Info.plist-/Permission-Verträge und Adaptergrenzen. Vor Freigabe: Xcode Build, iPhone-X/iOS-16.7.x Device-Test, Notification Authorization, AVAudioSession/AVAudioRecorder, Files/Document Picker, Background-/Lifecycle-Recovery.
